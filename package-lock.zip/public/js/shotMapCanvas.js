(function () {
  const canvas = document.getElementById("shotMapCanvas");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");

  // hidden field to submit JSON to server
  const hidden = document.getElementById("shot_map_json");
  const clearBtn = document.getElementById("shotMapClear");
  const modeBtns = document.querySelectorAll("[data-shot-mode]");

  let mode = "ground"; // "ground" or "aerial"
  let points = [];

  function resize() {
    // keep drawing crisp on high DPI screens
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    draw();
  }

  function drawPitch() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;

    // background
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#f8f9fa";
    ctx.fillRect(0, 0, w, h);

    // simple "pitch rectangle"
    ctx.strokeStyle = "#ced4da";
    ctx.lineWidth = 2;
    const pitchW = w * 0.35;
    const pitchH = h * 0.65;
    ctx.strokeRect((w - pitchW) / 2, (h - pitchH) / 2, pitchW, pitchH);

    // crease line
    ctx.beginPath();
    ctx.moveTo(w * 0.25, h * 0.5);
    ctx.lineTo(w * 0.75, h * 0.5);
    ctx.stroke();

    // labels
    ctx.fillStyle = "#6c757d";
    ctx.font = "12px Arial";
    ctx.fillText("LEG", 10, h / 2);
    ctx.fillText("OFF", w - 35, h / 2);
  }

  function drawPoints() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;

    points.forEach((p) => {
      const x = p.x * w;
      const y = p.y * h;

      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fillStyle = p.type === "aerial" ? "rgba(13,110,253,0.9)" : "rgba(25,135,84,0.9)";
      ctx.fill();
      ctx.strokeStyle = "white";
      ctx.lineWidth = 2;
      ctx.stroke();
    });
  }

  function draw() {
    drawPitch();
    drawPoints();
    syncHidden();
  }

  function syncHidden() {
    hidden.value = JSON.stringify(points);
  }

  function setMode(m) {
    mode = m;
    modeBtns.forEach((b) => b.classList.toggle("active", b.dataset.shotMode === m));
  }

  function handleClick(evt) {
    const rect = canvas.getBoundingClientRect();
    const x = (evt.clientX - rect.left) / rect.width;
    const y = (evt.clientY - rect.top) / rect.height;

    points.push({
      x: Number(x.toFixed(4)),
      y: Number(y.toFixed(4)),
      type: mode,
      ts: new Date().toISOString(),
    });

    draw();
  }

  // load existing JSON if present
  try {
    if (hidden.value) {
      const loaded = JSON.parse(hidden.value);
      if (Array.isArray(loaded)) points = loaded;
    }
  } catch (e) {
    // ignore bad JSON
  }

  canvas.addEventListener("click", handleClick);
  window.addEventListener("resize", resize);

  clearBtn?.addEventListener("click", () => {
    points = [];
    draw();
  });

  modeBtns.forEach((btn) => {
    btn.addEventListener("click", () => setMode(btn.dataset.shotMode));
  });

  setMode(mode);
  resize();
})();