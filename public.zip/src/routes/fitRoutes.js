// src/routes/fitRoutes.js
const express = require("express");
const router = express.Router();

const fitController = require("../controllers/fitController");

router.get("/start", fitController.start);
router.get("/step1", fitController.step1);

router.post("/shotmap", async (req, res) => {
  try {
    const fitId = req.body.fitId;
    const shotMap = req.body.shot_map_json || [];

    if (!fitId) return res.status(400).json({ ok: false, error: "fitId required" });

    // store as JSON string
    const shot_map_json = JSON.stringify(shotMap);

    // SQLite example:
    // UPDATE fits SET shot_map_json=? WHERE id=?
    await db.run("UPDATE fits SET shot_map_json = ? WHERE id = ?", [shot_map_json, fitId]);

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ✅ this is the key one:
router.post("/results", fitController.results);

module.exports = router;
